package net.codejava.fileupload.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import java.sql.Blob;

@Entity
@Table(name = "FILES_UPLOAD_H")
public class UploadFile {
	@Id
	@GeneratedValue
	@Column(name = "FILE_ID")
	private long id;

	@Column(name = "FILE_NAME")
	private String fileName;

	private byte[] data;

	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	// length=100000 is because to create longblob datatype in database else create tinyblob
	@Column(name = "FILE_DATA", unique = false, nullable = false, length = 100000)
	public  byte[] getData() {
		return data;
	}

	public void setData( byte[] data) {
		this.data = data;
	}

}
