package com.yash.spring.core;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestClass {

	public static void main(String[] args) {
	AnnotationConfigApplicationContext acap= new AnnotationConfigApplicationContext();
	acap.getEnvironment().setActiveProfiles("prod");
	acap.scan("com.yash.spring.core");
	acap.refresh();
	
	
	Employee employee=acap.getBean(Employee.class);
	System.out.println(employee.getName());
	acap.close();
	}
}
