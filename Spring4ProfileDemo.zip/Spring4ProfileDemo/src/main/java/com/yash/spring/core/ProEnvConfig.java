package com.yash.spring.core;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("prod")
public class ProEnvConfig {
	@Bean
	public Employee emp(){
		return new Employee(100, "Shyam Patidar Production");
	}
}
