package com.mkyong.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	DataSource dataSource;
	
	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder auth) throws Exception {
		System.out.println("config query..............");
		auth.jdbcAuthentication().dataSource(dataSource)
			.usersByUsernameQuery("select USERNAME,PASSWORD, ENABLED from users where USERNAME=?")
			.authoritiesByUsernameQuery("select USERNAME, USER_ROLE from user_roles where USERNAME=?");
	}	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		System.out.println("config role check..............");
		http.authorizeRequests()
			.antMatchers("/admin/**").access("hasRole('ROLE_ADMIN')")
			//.antMatchers("/hello/**").access("hasRole('ROLE_ADMIN')") //allow only amin to access hello page
			.and()
				.formLogin().loginPage("/login").failureUrl("/login?error")
					.usernameParameter("username").passwordParameter("password")
			
			.and()
				.logout().logoutSuccessUrl("/login?logout")
			.and()
				.exceptionHandling().accessDeniedPage("/403")
			.and()
				.csrf();
		
	}
}