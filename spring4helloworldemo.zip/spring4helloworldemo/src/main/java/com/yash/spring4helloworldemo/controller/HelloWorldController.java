package com.yash.spring4helloworldemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@Controller
@RequestMapping("/test")
public class HelloWorldController {
	

	@RequestMapping(value="hello",method=RequestMethod.GET)
	public String sayHello(Model model){
		System.out.println("----------controller--");
		model.addAttribute("greeting","hi... spring 4 MVC");
		return "welcome";
	}
	@RequestMapping(value="helloagain",method=RequestMethod.GET)
	public String sayHelloAgain(Model model){
		model.addAttribute("greeting","hi...again spring 4 MVC");
		return "welcome";
	}
}
