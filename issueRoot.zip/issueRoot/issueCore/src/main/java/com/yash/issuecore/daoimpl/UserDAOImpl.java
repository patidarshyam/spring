package com.yash.issuecore.daoimpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.yash.issuecore.dao.UserDAO;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.rowmapper.UserRowMapper;

@Repository
@Qualifier("userDao")
public class UserDAOImpl implements UserDAO {

	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(this.dataSource);
	}

	private Connection con = null;
	private Statement stmt = null;

	public int insert(User user) {
		String sql = "insert into users(firstname,lastname,email,loginname,password) values (?,?,?,?,?)";
		Object[] params={
		user.getFirstname(),
		user.getLastname(),
		user.getEmail(),
		user.getLoginname(),
		user.getPassword()};
		return jdbcTemplate.update(sql,params);	
	
	}

	public int update(User user) {
		String sql = "UPDATE users SET firstname=?,lastname=?,email=?,loginName=?,password=? WHERE id=?";
		Object[] params={
		user.getFirstname(),
		user.getLastname(),
		user.getEmail(),
		user.getLoginname(),
		user.getPassword(),
		user.getId()};
		
		return jdbcTemplate.update(sql,params);
	}

//	public int delete(User user) {
//		String sql= "delete from contacts where id=?";
//		return jdbcTemplate.update(sql,user.getId());
//	}

	public List<User> getUserList() {
		String sql="SELECT * FROM users";
		return jdbcTemplate.query(sql,new UserRowMapper());
	}

	public User getUserById(int id) {
		String sql="SELECT * FROM users where id=?";
		return jdbcTemplate.queryForObject(sql,new UserRowMapper(),id);
	}

}
