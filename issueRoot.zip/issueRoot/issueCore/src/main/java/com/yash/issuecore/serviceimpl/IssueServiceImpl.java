package com.yash.issuecore.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.issuecore.dao.IssueDAO;
import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.service.IssueService;
@Service
public class IssueServiceImpl implements IssueService {
	@Autowired
	private IssueDAO issueDAO;
	
	public List<Issue> listIssue() {
		return issueDAO.listIssue();
	}

	public int add(Issue issue) {
		return issueDAO.insert(issue);
	}

	public Issue getIssueById(int id) {
		return issueDAO.listIssueById(id);
	}

	public int edit(Issue issue) {
		return issueDAO.update(issue);
	}

}
