package com.yash.issuecore.dao;

import java.util.List;

import com.yash.issuecore.domain.User;

public interface UserDAO {

	public int insert(User user);
	public int update(User user);
//	public int delete(User user);
	public List<User> getUserList();
	public User getUserById(int id);
}
