package com.yash.issuecore.service;

import java.util.List;

import com.yash.issuecore.domain.User;


/**
 * This interface provides the services related to user.
 * @author shyam.patidar
 *
 */

public interface UserService {
	/**
	 * This method register the user.
	 * @param user
	 * @return int
	 */
	public int addUser(User user);
	
	public User authenticateUser(User user);
	
	public int userUpdate(User user);

	public List<User> listUser();
	
	public User getUser(int userId);

	
}
