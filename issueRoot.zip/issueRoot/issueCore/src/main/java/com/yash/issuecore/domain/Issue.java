package com.yash.issuecore.domain;

import java.util.Date;
import org.springframework.stereotype.Component;

@Component
public class Issue {
	private int id;
	private String issue;
	private String issue_description;
	private Date created_date;
	private int issue_type;
	private int statusid;
	private int userid;
	
	public Issue() {
		// TODO Auto-generated constructor stub
	}
	
	public Issue(int id, String issue, String issue_description, Date created_date, int issue_type, int statusid,
			int userid) {
		super();
		this.id = id;
		this.issue = issue;
		this.issue_description = issue_description;
		this.created_date = created_date;
		this.issue_type = issue_type;
		this.statusid = statusid;
		this.userid = userid;
	}


	public int getStatusid() {
		return statusid;
	}
	public void setStatusid(int statusid) {
		this.statusid = statusid;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public String getIssue_description() {
		return issue_description;
	}
	public void setIssue_description(String issue_description) {
		this.issue_description = issue_description;
	}
	public int getIssue_type() {
		return issue_type;
	}
	public void setIssue_type(int issue_type) {
		this.issue_type = issue_type;
	}
	

}