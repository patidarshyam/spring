package com.yash.test;
 
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.yash.issuecore.configuration.issueCoreConfig;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.service.UserService;


 
public class App {
 
    public static void main(String args[]) {
 
        AbstractApplicationContext context = new AnnotationConfigApplicationContext(issueCoreConfig.class);
        UserService personService = (UserService) context.getBean("userService");
 
        User user=new User();
		user.setEmail("shyam@123");
		user.setFirstname("Shyam");
		user.setLastname("Patidar");
		user.setLoginname("shyam");
		user.setPassword("shyam123");
			
		User user1=new User();
		user1.setEmail("sh@123");
		user1.setFirstname("Sh");
		user1.setLastname("Pati");
		user1.setLoginname("sh");
		user1.setPassword("sh123");
 
        personService.addUser(user);
        personService.addUser(user1);
       
 
        System.out.println("Find All users");
        List < User> persons = personService.listUser();
        for (User person: persons) {
            System.out.println(person);
        }
 
//        System.out.println("Delete person Id = 3");
//        int deleteMe = 3;
//        personService.deletePerson(deleteMe);
// 
//        yashwant.setFirstName("Yashwant - Updated");
//        yashwant.setLastName("Chavan - Updated");
//        yashwant.setAge(40);
// 
//        System.out.println("Update person Id = 1");
//        int updateMe = 1;
//        personService.editPerson(yashwant, updateMe);
// 
//        System.out.println("Find person Id = 2");
//        Person person = personService.find(2);
//        System.out.println(person);
// 
//        System.out.println("Find All Again");
//        persons = personService.findAll();
//        for (Person p: persons) {
//            System.out.println(p);
//        }

        context.close();
    }
 
}