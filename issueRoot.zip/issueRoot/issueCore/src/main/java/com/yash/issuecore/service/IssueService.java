package com.yash.issuecore.service;

import java.util.List;

import com.yash.issuecore.domain.Issue;

public interface IssueService {
	
	public List<Issue> listIssue();
	public int add(Issue issue);
	public Issue getIssueById(int id);
	public int edit(Issue issue);
}
