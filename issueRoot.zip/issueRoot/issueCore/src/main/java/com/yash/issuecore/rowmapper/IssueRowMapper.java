package com.yash.issuecore.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.issuecore.domain.Issue;

public class IssueRowMapper implements RowMapper<Issue> {

	public Issue mapRow(ResultSet rs, int rownum) throws SQLException {
		Issue issue=new Issue();
		issue.setIssue(rs.getString("issue"));
		issue.setIssue_description(rs.getString("issue_description"));
		issue.setCreated_date(rs.getDate("created_date"));
		issue.setId(rs.getInt("id"));
		issue.setIssue_type(rs.getInt("issue_type"));
		issue.setUserid(rs.getInt("userid"));
		issue.setStatusid(rs.getInt("statusid"));
		return issue;
	}
}
