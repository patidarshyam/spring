package com.yash.issuecore.domain;

import org.springframework.stereotype.Component;

@Component
public class User {
	private int statusid;
	private int roleid;
	private int id;
	private String firstname;
	private String lastname;
	private String email;
	private String loginname;
	private String password;
	
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public User(int statusid, int roleid, int id, String firstname, String lastname, String email, String loginname,
			String password) {
		super();
		this.statusid = statusid;
		this.roleid = roleid;
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.loginname = loginname;
		this.password = password;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getStatusid() {
		return statusid;
	}
	public void setStatusid(int statusid) {
		this.statusid = statusid;
	}
	public int getRoleid() {
		return roleid;
	}
	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}
	
}
