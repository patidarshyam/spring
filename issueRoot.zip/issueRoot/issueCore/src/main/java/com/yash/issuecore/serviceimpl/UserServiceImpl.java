package com.yash.issuecore.serviceimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.yash.issuecore.dao.UserDAO;
import com.yash.issuecore.domain.User;
import com.yash.issuecore.rowmapper.UserRowMapper;
import com.yash.issuecore.service.UserService;

/**
 * This class is the implementation of userService interface
 * @author shyam.patidar
 *
 */
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Autowired
	private UserDAO userDAO;
	/**
	 * This method register the user.
	 */
	public int addUser(User user) {
		return userDAO.insert(user);
	}
	
	public User authenticateUser(User user) {
		String sql="SELECT * FROM users WHERE loginname=? AND password=?";
		Object[] params=new Object[]{
				user.getLoginname(),
				user.getPassword()
			};
		try{
			return jdbcTemplate.queryForObject(sql,params,new UserRowMapper());
		}catch (Exception e) {
			return null;
		}
	}
	
	public List<User> listUser() {
		return userDAO.getUserList();
	}
	
	public int userUpdate(User user) {
		return userDAO.update(user);
	}

	public User getUser(int userId) {
		return userDAO.getUserById(userId);
	}
	
	
}
