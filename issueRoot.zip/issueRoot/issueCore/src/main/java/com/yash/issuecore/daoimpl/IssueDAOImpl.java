package com.yash.issuecore.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.issuecore.dao.IssueDAO;
import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.rowmapper.IssueRowMapper;

@Repository
@Qualifier("issueDao")
public class IssueDAOImpl implements IssueDAO {

	@Autowired
	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemplate;
	
	public DataSource getDataSource() {
		return dataSource;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(this.dataSource);
	}
	public List<Issue> listIssue() {
		String sql="SELECT * FROM issues";
		return jdbcTemplate.query(sql,new IssueRowMapper());
	}

	public int insert(Issue issue) {
		String sql = "insert into issues(issue,issue_type,userid,issue_description,created_Date,statusid) values (?,?,?,?,?,?)";
		Object[] params={
		issue.getIssue(),
		issue.getIssue_type(),
		issue.getUserid(),
		issue.getIssue_description(),
		issue.getCreated_date(),
		issue.getStatusid()};
		return jdbcTemplate.update(sql,params);	
	}

	public Issue listIssueById(int id) {
		String sql="SELECT * FROM issues where id=?";
		return jdbcTemplate.queryForObject(sql,new IssueRowMapper(),id);
	}

	public int update(Issue issue) {
		String sql = "UPDATE issues SET issue=?,issue_type=?,issue_description=?,created_Date=?,statusid=? where id=?";
		Object[] params={
		issue.getIssue(),
		issue.getIssue_type(),
		issue.getIssue_description(),
		issue.getCreated_date(),
		issue.getStatusid(),
		issue.getId()};
		return jdbcTemplate.update(sql,params);	
	}

}
