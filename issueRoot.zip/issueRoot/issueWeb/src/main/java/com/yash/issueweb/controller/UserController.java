package com.yash.issueweb.controller;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.issuecore.domain.User;
import com.yash.issuecore.service.UserService;

@RestController
//@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/users")
public class UserController {
	 static Logger logger = Logger.getLogger(UserController.class.getName());
	@Autowired
	UserService userService;
	
	@RequestMapping(value="/list",method = RequestMethod.GET)
	public List<User> getAllUser(HttpServletRequest request) {
		User usersession=(User)request.getSession().getAttribute("loggedInUser");
		if(usersession==null)
			return null;
		else {
			 return userService.listUser();
		}
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public User getUserById(@PathVariable("id")int id,HttpServletRequest request) {
		User usersession=(User)request.getSession().getAttribute("loggedInUser");
		if(usersession==null)
			return null;
		else {
			return userService.getUser(id);
		}
		
	}
	
	@RequestMapping(value="/add",method = RequestMethod.POST)
	public int addUser(@RequestBody User user,HttpServletRequest request) {
		User usersession=(User)request.getSession().getAttribute("loggedInUser");
		if(usersession==null)
			return 0;
		else {
			return userService.addUser(user);
		}
		
	}
	
	@RequestMapping(value="/update",method = RequestMethod.PUT)
	public int updateUser(@RequestBody User user,HttpServletRequest request) {
		User usersession=(User)request.getSession().getAttribute("loggedInUser");
		if (usersession == null)
			return 0;
		else {
			return userService.userUpdate(user);
		}
		
	}
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String processUserLogin(@RequestBody User user,HttpServletRequest request) {
		user = userService.authenticateUser(user);
		if (user == null) {
			return "Login Failed!";
		}else{
			createSession(request, user);
			if(user.getRoleid()==2)
				return "userDashboard- Login success! Welcome "+user.getFirstname()+" !!!!";
			else
				return "adminDashboard- "+user.getFirstname()+" Login success! Welcome Admin!!!!";
			
		}
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String processUserLogout(Model model, HttpServletRequest	request) {
		logger.info("before invalidate "+request.getSession().getAttribute("loggedInUser"));
		request.getSession().invalidate();
		logger.info("after invalidate "+request.getSession().getAttribute("loggedInUser"));
		return "Successfully Logged out!";
	}
	
	public void createSession(HttpServletRequest request, User loggedInUser) { 
		request.getSession().setAttribute("loggedInUser", loggedInUser);
	}


}
