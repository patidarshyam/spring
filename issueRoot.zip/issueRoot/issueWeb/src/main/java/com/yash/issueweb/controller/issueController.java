package com.yash.issueweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.issuecore.domain.Issue;
import com.yash.issuecore.service.IssueService;

@RestController
@RequestMapping("/issues")
public class issueController {
	@Autowired
	IssueService issueService;
	
	@RequestMapping(method = RequestMethod.GET)
	public List<Issue> getAllIssue() {
		 return issueService.listIssue();
	}
	
	@RequestMapping(value="/{id}",method = RequestMethod.GET)
	public Issue getIssueById(@PathVariable("id")int id) {
		return issueService.getIssueById(id);
	}

	@RequestMapping(value="/add",method = RequestMethod.POST)
	public int addIssue(@RequestBody Issue issue) {
		return issueService.add(issue);
	}

	@RequestMapping(value="/update",method = RequestMethod.PUT)
	public int updateIssue(@RequestBody Issue issue) {
		return issueService.edit(issue);
	}
}
