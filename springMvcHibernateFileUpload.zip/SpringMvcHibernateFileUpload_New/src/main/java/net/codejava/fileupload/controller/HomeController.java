package net.codejava.fileupload.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import net.codejava.fileupload.dao.FileUploadDAO;
import net.codejava.fileupload.model.UploadFile;

/**
 * Handles requests for the file upload page.
 */
@Controller
public class HomeController {
	@Autowired
	private FileUploadDAO fileUploadDao;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String showUploadForm(HttpServletRequest request) {
		return "Upload";
	}

	@RequestMapping(value = "/doUpload", method = RequestMethod.POST)
	public String handleFileUpload(HttpServletRequest request, @RequestParam MultipartFile file) {
		System.out.println(" file : " + file.getOriginalFilename());
		if (file != null) {
			System.out.println("Save file : " + file.getOriginalFilename());
			UploadFile uploadFile = new UploadFile();
			uploadFile.setFileName(file.getOriginalFilename());
			try {
				//uploadFile.setData(file.getBytes()); // this is used when tinyblob datatype created in database

				Blob blobFile = new SerialBlob(file.getBytes());
				
				uploadFile.setData(blobFile);
				fileUploadDao.save(uploadFile);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return "Success";
	}
	// @RequestMapping(value = "/doUpload", method = RequestMethod.POST)
	// public String handleFileUpload(HttpServletRequest request, @RequestParam
	// MultipartFile fileUpload)
	// throws Exception {
	//
	// if (fileUpload != null) {
	//
	// System.out.println("Saving file: " + fileUpload.getOriginalFilename());
	//
	// UploadFile uploadFile = new UploadFile();
	// uploadFile.setFileName(fileUpload.getOriginalFilename());
	// uploadFile.setData(fileUpload.getBytes());
	//
	// fileUploadDao.save(uploadFile);
	// }
	//
	// return "Success";
	// }
}
