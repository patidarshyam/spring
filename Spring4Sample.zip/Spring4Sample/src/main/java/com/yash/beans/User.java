package com.yash.beans;

public class User {
	int id;
	String name;
	Address homeAddress;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	
	public void showUserDetails(){
		System.out.println("Id :"+getId());
		System.out.println("Name :"+getName());
		System.out.println("Home Address");
		System.out.println("house no :"+getHomeAddress().getHouseNo());
		System.out.println("City :"+getHomeAddress().getCity());
		System.out.println("State "+getHomeAddress().getState());
	}
	
}
