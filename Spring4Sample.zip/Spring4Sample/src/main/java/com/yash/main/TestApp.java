package com.yash.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.yash.beans.User;

public class TestApp {

	public static void main(String[] args) {
	ApplicationContext context=	new AnnotationConfigApplicationContext(BeanConfig.class);
	
	User user=(User)context.getBean("user");
	user.showUserDetails();
	}

}
