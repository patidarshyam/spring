package com.yash.main;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.yash.beans.Address;
import com.yash.beans.User;

@Configuration
@ComponentScan(basePackages="com.yash.beans")
public class BeanConfig {
	@Bean
	public User user(){
		User user=new User();
		user.setId(1);
		user.setName("Shyam");
		user.setHomeAddress(homeAddress()); // this is same as 2ndory type DI  as ref
		return user;
	}
	@Bean
	public Address homeAddress(){
	Address homeAddress=new Address();
	homeAddress.setCity("indore"); // setXxx() is equal to >property>
	homeAddress.setHouseNo("121");
	homeAddress.setState("mp");
	homeAddress.setZip("4564564");
	return homeAddress;
	}
}
